package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class SampleController {

    @FXML
    private AnchorPane homePage;
    @FXML
    private Label homeLabel;
    @FXML
    private Button need;
    @FXML
    private Button give;
    @FXML
    private Button inv;
    @FXML
    private AnchorPane needPage;
    @FXML
    private Button homeButton;
    @FXML
    private AnchorPane invPage;
    @FXML
    private Button userSubmit;
    @FXML
    private TextField userField;
    @FXML
    private TextField itemField;
    @FXML
    private TextField quantityField;
    @FXML
    private Button add;
    @FXML
    private Button sub;
    private int ticker = 0;
    private String[] users = new String[50];
    private String[] items = new String[50];
    private int[] quantity = new int[50];

    public void openNeedGive(ActionEvent event) throws IOException {  //Function opens the Need/Give page from the buttons give and need from the home menu

        needPage = (AnchorPane)FXMLLoader.load(getClass().getResource("NeedGive.fxml"));
        Scene scene = new Scene(needPage,500,500);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Need/Give");
        window.setScene(scene);
        window.show();
        
        
    
    }
    	
    public void adding(ActionEvent event) throws IOException
    {
    	
    	
    	
    	String userTemp = userField.getText();
    	String itemTemp = itemField.getText();
    	int tempQuantity = Integer.parseInt(quantityField.getText());
    	users[ticker] = userTemp;
    	items[ticker] = itemTemp;
    	quantity[ticker] = tempQuantity;
    	System.out.println("User: " + users[ticker]);
    	System.out.println("Items: " + items[ticker]);
    	System.out.println("Amount: " + quantity[ticker]);
    	userField.clear();
    	itemField.clear();
    	quantityField.clear();
    	ticker++;
    }
    
    public void subtraction(ActionEvent event) throws IOException
    {
    	
    	
    	
    	String userTemp = userField.getText();
    	String itemTemp = itemField.getText();
    	int tempQuantity = Integer.parseInt(quantityField.getText());
    	users[ticker] = userTemp;
    	items[ticker] = itemTemp;
    	quantity[ticker] = tempQuantity;
    	System.out.println("You would like to remove: ");
    	System.out.println("User: " + users[ticker]);
    	System.out.println("Items: " + items[ticker]);
    	System.out.println("Amount: " + quantity[ticker]);
    	userField.clear();
    	itemField.clear();
    	quantityField.clear();
    	ticker++;
    }

    public int search(String[] array, String find)
    {
    	int found = 0;
    	
    	
    	return found;
    }
    
    
    public void openHome(ActionEvent event) throws IOException {                         //Function send the user back to the home menu when they press the home button on pages

        homePage = (AnchorPane)FXMLLoader.load(getClass().getResource("Sample.fxml"));
        Scene scene = new Scene(homePage,500,500);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Home");
        window.setScene(scene);
        window.show();

    }
    
    public void openInv(ActionEvent event) throws IOException {                         //Function opens the Inventory page from the menu button labeled inventory

        invPage = (AnchorPane)FXMLLoader.load(getClass().getResource("Inventory.fxml"));
        Scene scene = new Scene(invPage,500,500);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setTitle("Inventory");
        window.setScene(scene);
        window.show();

    }

}